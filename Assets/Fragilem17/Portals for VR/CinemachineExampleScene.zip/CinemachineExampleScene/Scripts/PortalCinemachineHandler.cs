using Cinemachine;
using Fragilem17.MirrorsAndPortals;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalCinemachineHandler : MonoBehaviour
{
    public PortalableObject CharacterController;
    public PortalableObject MainCamera;

    public CinemachineVirtualCamera CinemamachineCamera;

    private Portal _portalMainCam;
    private Portal _portalCharackter;

    private Vector3 _previousPos;

    void Start()
    {
        CharacterController.OnPrePortalEvent.AddListener(OnCharacterPrePortal);

        MainCamera.OnPrePortalEvent.AddListener(OnMainCamPrePortal);
        MainCamera.OnPostPortalEvent.AddListener(OnMainCamPostPortal);
    }

    private void OnCharacterPrePortal(PortalableObject po, Portal fromPortal)
    {
        _portalCharackter = fromPortal.OtherPortal;
        if (_portalMainCam == null) {
            _portalMainCam = fromPortal;
        }
        SetCorrectLookAts();
    }

    private void OnMainCamPrePortal(PortalableObject po, Portal fromPortal)
    {
        _portalMainCam = fromPortal.OtherPortal;
        if (_portalCharackter == null)
        {
            _portalCharackter = fromPortal;
        }

        _previousPos = CinemamachineCamera.LookAt.position;
    }

    private void OnMainCamPostPortal(PortalableObject po, Portal fromPortal)
    {
        SetCorrectLookAts();

        Vector3 newPos = CinemamachineCamera.LookAt.position;
        Quaternion newRot = po.TransformToPortal.transform.rotation;

        Vector3 posDelta = newPos - _previousPos;
        CinemamachineCamera.OnTargetObjectWarped(CinemamachineCamera.LookAt, posDelta);
    }

    private void SetCorrectLookAts()
    {
        // is the MainCamera on the same side of the same portal as the Charackter?
        if (_portalCharackter == _portalMainCam)
        {
            // then follow the real one
            CinemamachineCamera.LookAt = CharacterController.transform;
            CinemamachineCamera.Follow = CharacterController.transform;
        }
        else
        {
            // else follow the clone
            CinemamachineCamera.LookAt = CharacterController.ClonePositionToClosestPortal.transform;
            CinemamachineCamera.Follow = CharacterController.ClonePositionToClosestPortal.transform;
        }
    }
}
